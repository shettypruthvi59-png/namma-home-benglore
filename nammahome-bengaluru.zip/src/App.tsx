/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  HelpCircle, 
  ArrowRight, 
  Mail, 
  Smartphone, 
  MapPin, 
  Bell, 
  Search, 
  Calculator, 
  PlusCircle, 
  Heart, 
  Verified, 
  Home as HomeIcon, 
  Briefcase, 
  User,
  ArrowLeft,
  Share2,
  Bed,
  Bath,
  Car,
  Calendar,
  MessageSquare,
  Phone,
  Map as MapIcon,
  Filter,
  Minus,
  Plus,
  Navigation
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Property, Screen } from './types';

// Mock Data
const TRENDING_PROJECTS: Property[] = [
  {
    id: '1',
    title: "Prestige King's County",
    location: "Rajapura, Bengaluru",
    price: "₹1.2 Cr - 2.5 Cr",
    sqft: "1,200 - 2,400 sq.ft",
    type: "Plot",
    bhk: "N/A",
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=800&q=80",
    isRera: true,
    amenities: ["Clubhouse", "Gym", "Pool"],
    owner: { name: "Prestige Group", type: "Builder", initials: "PG" }
  },
  {
    id: '2',
    title: "Brigade El Dorado",
    location: "Aerospace Park, North BLR",
    price: "₹85 L - 1.4 Cr",
    sqft: "795 - 1,560 sq.ft",
    type: "Apartment",
    bhk: "2 & 3 BHK",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80",
    isRera: true,
    amenities: ["Park", "Jogging Track", "Security"],
    owner: { name: "Brigade Group", type: "Builder", initials: "BG" }
  }
];

const NEW_LAUNCHES: Property[] = [
  {
    id: '3',
    title: "Sobha Windsor",
    location: "Whitefield, Bengaluru",
    price: "₹2.1 Cr onwards",
    sqft: "1,550 - 2,200 sq.ft",
    type: "Apartment",
    bhk: "3 & 4 BHK",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80",
    isVerified: true,
    amenities: ["Private Garden", "Luxury Lobby"],
    owner: { name: "Sobha Ltd", type: "Builder", initials: "SL" }
  },
  {
    id: '4',
    title: "Godrej Splendour",
    location: "Whitefield, Bengaluru",
    price: "₹1.75 Cr onwards",
    sqft: "1,200 - 1,800 sq.ft",
    type: "Apartment",
    bhk: "2 & 3 BHK",
    image: "https://images.unsplash.com/photo-1448630360428-65456885c650?auto=format&fit=crop&w=800&q=80",
    isVerified: true,
    amenities: ["Smart Home", "EV Charging"],
    owner: { name: "Godrej Properties", type: "Builder", initials: "GP" }
  }
];

const SELECTED_PROPERTY: Property = {
  id: '5',
  title: "4 BHK Luxury Villa",
  location: "JP Nagar, Phase 7, Bengaluru",
  price: "₹2.5 Cr",
  sqft: "3,200 sq.ft",
  type: "Villa",
  bhk: "4 BHK",
  image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80",
  isVerified: true,
  amenities: ["Private Garden", "Clubhouse", "Swimming Pool", "Gymnasium", "Home Theater"],
  owner: { name: "Ramesh Kumar", type: "Property Owner", initials: "RK" }
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [selectedProp, setSelectedProp] = useState<Property | null>(null);

  const navigateTo = (screen: Screen, prop: Property | null = null) => {
    if (prop) setSelectedProp(prop);
    setCurrentScreen(screen);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark flex justify-center selection:bg-primary/30">
      <div className="relative flex h-full min-h-screen w-full max-w-[480px] flex-col bg-white dark:bg-background-dark overflow-x-hidden shadow-2xl">
        <AnimatePresence mode="wait">
          {currentScreen === 'login' && (
            <div key="login" className="h-full">
              <LoginScreen onLogin={() => navigateTo('home')} />
            </div>
          )}
          {currentScreen === 'home' && (
            <div key="home">
              <HomeScreen 
                onSelectProperty={(p) => navigateTo('details', p)} 
                onOpenMap={() => navigateTo('map')}
              />
            </div>
          )}
          {currentScreen === 'details' && (
            <div key="details">
              <DetailsScreen 
                property={selectedProp || SELECTED_PROPERTY} 
                onBack={() => navigateTo('home')} 
              />
            </div>
          )}
          {currentScreen === 'map' && (
            <div key="map" className="h-full">
              <MapScreen 
                onBack={() => navigateTo('home')} 
                onSelectProperty={(p) => navigateTo('details', p)}
              />
            </div>
          )}
        </AnimatePresence>

        {/* Bottom Navigation - Only for Home and Map */}
        {(currentScreen === 'home' || currentScreen === 'map') && (
          <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] border-t border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-background-dark/80 backdrop-blur-xl px-4 pb-6 pt-3 z-50">
            <div className="flex justify-between items-center">
              <button 
                onClick={() => navigateTo('home')}
                className={`flex flex-col items-center gap-1 ${currentScreen === 'home' ? 'text-primary' : 'text-slate-400'}`}
              >
                <HomeIcon size={24} fill={currentScreen === 'home' ? "currentColor" : "none"} />
                <p className="text-[10px] font-bold">Home</p>
              </button>
              <button 
                onClick={() => navigateTo('map')}
                className={`flex flex-col items-center gap-1 ${currentScreen === 'map' ? 'text-primary' : 'text-slate-400'}`}
              >
                <MapIcon size={24} fill={currentScreen === 'map' ? "currentColor" : "none"} />
                <p className="text-[10px] font-medium">Explore</p>
              </button>
              <button className="flex flex-col items-center gap-1 text-slate-400">
                <Heart size={24} />
                <p className="text-[10px] font-medium">Saved</p>
              </button>
              <button className="flex flex-col items-center gap-1 text-slate-400">
                <Briefcase size={24} />
                <p className="text-[10px] font-medium">Services</p>
              </button>
              <button className="flex flex-col items-center gap-1 text-slate-400">
                <User size={24} />
                <p className="text-[10px] font-medium">Account</p>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col h-full"
    >
      {/* Top Nav */}
      <div className="flex items-center justify-between px-4 py-4 pt-6">
        <div className="flex items-center gap-2">
          <Globe className="text-primary" size={20} />
          <div className="flex bg-slate-100 dark:bg-slate-800 rounded-lg p-1">
            <button className="px-3 py-1 text-xs font-bold bg-white dark:bg-slate-700 rounded shadow-sm text-primary">English</button>
            <button className="px-3 py-1 text-xs font-medium text-slate-500 dark:text-slate-400">ಕನ್ನಡ</button>
          </div>
        </div>
        <button className="text-slate-400">
          <HelpCircle size={20} />
        </button>
      </div>

      {/* Hero Image */}
      <div className="px-4 py-3">
        <div 
          className="w-full bg-center bg-no-repeat bg-cover flex flex-col justify-end overflow-hidden bg-slate-200 rounded-2xl min-h-[260px] relative shadow-xl"
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1590644365607-1c5a519a7a37?auto=format&fit=crop&w=1200&q=80")' }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
          <div className="relative p-6">
            <span className="inline-block bg-primary px-3 py-1 rounded-full text-[10px] font-bold text-white uppercase tracking-wider mb-2">Bengaluru Homes</span>
            <h1 className="text-white tracking-tight text-3xl font-bold leading-tight">Find Your Perfect Home in Bengaluru</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-8">
        <div className="mb-8">
          <h2 className="text-slate-900 dark:text-slate-100 text-2xl font-bold">Welcome Back</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-2">Enter your mobile number to receive a verification code for secure login.</p>
        </div>

        <div className="flex flex-col gap-4">
          <label className="flex flex-col gap-2">
            <p className="text-slate-700 dark:text-slate-300 text-sm font-semibold">Mobile Number</p>
            <div className="flex items-center gap-0 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800/50 focus-within:ring-2 focus-within:ring-primary/20 focus-within:border-primary transition-all">
              <div className="flex items-center gap-2 px-4 py-4 border-r border-slate-200 dark:border-slate-700">
                <span className="text-xl">🇮🇳</span>
                <span className="text-slate-900 dark:text-slate-100 font-bold">+91</span>
              </div>
              <input 
                className="flex-1 bg-transparent border-none focus:ring-0 text-slate-900 dark:text-slate-100 text-lg font-medium placeholder:text-slate-400 h-14 px-4" 
                maxLength={10} 
                placeholder="00000 00000" 
                type="tel"
              />
            </div>
          </label>

          <div className="mt-4">
            <button 
              onClick={onLogin}
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/25 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <span>Get OTP</span>
              <ArrowRight size={20} />
            </button>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-slate-500 dark:text-slate-400 text-[11px]">
            By continuing, you agree to our 
            <a className="text-primary font-semibold hover:underline mx-1" href="#">Terms of Service</a> & 
            <a className="text-primary font-semibold hover:underline mx-1" href="#">Privacy Policy</a>
          </p>
        </div>
      </div>

      {/* Social Login */}
      <div className="px-6 pb-12 mt-auto">
        <div className="flex items-center gap-4 mb-6">
          <div className="h-[1px] flex-1 bg-slate-200 dark:bg-slate-800"></div>
          <span className="text-slate-400 text-[10px] font-medium uppercase tracking-widest">or login with</span>
          <div className="h-[1px] flex-1 bg-slate-200 dark:bg-slate-800"></div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <button className="flex items-center justify-center gap-2 border border-slate-200 dark:border-slate-700 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
            <Mail size={18} className="text-slate-600 dark:text-slate-400" />
            <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Email</span>
          </button>
          <button className="flex items-center justify-center gap-2 border border-slate-200 dark:border-slate-700 py-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
            <Smartphone size={18} className="text-slate-600 dark:text-slate-400" />
            <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Apple ID</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function HomeScreen({ onSelectProperty, onOpenMap }: { onSelectProperty: (p: Property) => void, onOpenMap: () => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="flex flex-col pb-24"
    >
      {/* Header */}
      <div className="flex items-center bg-white dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="text-primary flex size-10 shrink-0 items-center justify-center bg-primary/10 rounded-full">
            <MapPin size={20} />
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Location</span>
            <h2 className="text-slate-900 dark:text-slate-100 text-base font-bold leading-tight tracking-tight">Indiranagar, Bengaluru</h2>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="flex size-10 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            <Bell size={20} />
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="px-4 py-3 sticky top-[60px] bg-white dark:bg-background-dark z-40">
        <div className="flex w-full items-stretch rounded-xl h-12 shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
          <div className="text-slate-400 flex bg-slate-50 dark:bg-slate-800 items-center justify-center pl-4">
            <Search size={18} />
          </div>
          <input 
            className="flex-1 border-none bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-0 h-full placeholder:text-slate-400 px-4 text-sm font-medium" 
            placeholder="Search properties in Bengaluru" 
          />
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-3 px-4 py-2 overflow-x-auto no-scrollbar">
        {['Buy', 'Rent', 'Plots', 'Commercial'].map((filter, i) => (
          <button 
            key={filter}
            className={`flex h-9 shrink-0 items-center justify-center gap-x-2 rounded-full px-5 text-sm font-medium transition-all ${i === 0 ? 'bg-primary text-white shadow-md shadow-primary/20' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'}`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3 p-4">
        <button className="flex flex-col gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 items-start shadow-sm transition-all active:scale-95 text-left">
          <div className="text-primary bg-primary/10 p-2 rounded-lg">
            <Calculator size={20} />
          </div>
          <h2 className="text-slate-900 dark:text-slate-100 text-sm font-bold">EMI Calculator</h2>
        </button>
        <button className="flex flex-col gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4 items-start shadow-sm transition-all active:scale-95 text-left">
          <div className="text-primary bg-primary/10 p-2 rounded-lg">
            <PlusCircle size={20} />
          </div>
          <h2 className="text-slate-900 dark:text-slate-100 text-sm font-bold">Post Property</h2>
        </button>
      </div>

      {/* Trending Projects */}
      <div className="mt-4">
        <div className="flex items-center justify-between px-4 mb-4">
          <h3 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">Trending Projects</h3>
          <button className="text-primary text-xs font-bold uppercase tracking-wider">See All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar px-4">
          {TRENDING_PROJECTS.map((prop) => (
            <div 
              key={prop.id}
              onClick={() => onSelectProperty(prop)}
              className="min-w-[280px] bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-sm active:scale-[0.98] transition-transform cursor-pointer"
            >
              <div className="relative h-40 w-full bg-slate-200">
                <img 
                  alt={prop.title} 
                  className="h-full w-full object-cover" 
                  src={prop.image} 
                  referrerPolicy="no-referrer"
                />
                {prop.isRera && (
                  <div className="absolute top-3 right-3 bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1">
                    <Verified size={12} /> RERA
                  </div>
                )}
              </div>
              <div className="p-4">
                <h4 className="font-bold text-slate-900 dark:text-slate-100 mb-1">{prop.title}</h4>
                <p className="text-xs text-slate-500 mb-2 flex items-center gap-1">
                  <MapPin size={14} /> {prop.location}
                </p>
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-lg font-extrabold text-primary">{prop.price}</p>
                    <p className="text-[10px] text-slate-400">{prop.sqft}</p>
                  </div>
                  <button className="bg-primary/10 text-primary p-2 rounded-lg">
                    <Heart size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* New Launches */}
      <div className="mt-8">
        <div className="flex items-center justify-between px-4 mb-4">
          <div>
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">New Launches</h3>
            <p className="text-xs text-slate-500 font-medium">In Whitefield, Bengaluru</p>
          </div>
          <button className="text-primary text-xs font-bold uppercase tracking-wider">See All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar px-4 mb-8">
          {NEW_LAUNCHES.map((prop) => (
            <div 
              key={prop.id}
              onClick={() => onSelectProperty(prop)}
              className="min-w-[200px] bg-white dark:bg-slate-800 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm active:scale-[0.98] transition-transform cursor-pointer"
            >
              <div className="relative h-32 w-full">
                <img 
                  alt={prop.title} 
                  className="h-full w-full object-cover" 
                  src={prop.image} 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-1 rounded">
                  {prop.price}
                </div>
              </div>
              <div className="p-3">
                <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{prop.title}</p>
                <p className="text-[10px] text-slate-500">{prop.bhk}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function DetailsScreen({ property, onBack }: { property: Property, onBack: () => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      className="flex flex-col pb-32"
    >
      {/* Top Nav */}
      <div className="sticky top-0 z-50 flex items-center bg-white/80 dark:bg-slate-900/80 backdrop-blur-md p-4 justify-between">
        <button 
          onClick={onBack}
          className="text-slate-900 dark:text-slate-100 flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-slate-900 dark:text-slate-100 text-lg font-bold leading-tight tracking-tight flex-1 text-center truncate px-4">
          {property.title}
        </h2>
        <div className="flex gap-2">
          <button className="text-slate-900 dark:text-slate-100 flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <Share2 size={20} />
          </button>
          <button className="text-slate-900 dark:text-slate-100 flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <Heart size={20} />
          </button>
        </div>
      </div>

      {/* Hero Image */}
      <div className="px-4 py-2">
        <div 
          className="bg-cover bg-center flex flex-col justify-end overflow-hidden rounded-2xl min-h-80 relative shadow-lg"
          style={{ backgroundImage: `linear-gradient(0deg, rgba(0, 0, 0, 0.6) 0%, rgba(0, 0, 0, 0) 40%), url("${property.image}")` }}
        >
          <div className="absolute top-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
            1 / 12
          </div>
          <div className="flex justify-center gap-1.5 p-5">
            <div className="w-6 h-1 rounded-full bg-white"></div>
            <div className="w-2 h-1 rounded-full bg-white/40"></div>
            <div className="w-2 h-1 rounded-full bg-white/40"></div>
            <div className="w-2 h-1 rounded-full bg-white/40"></div>
          </div>
        </div>
      </div>

      {/* Header Info */}
      <div className="px-4 pt-4">
        <div className="flex items-baseline justify-between">
          <h1 className="text-slate-900 dark:text-slate-100 text-3xl font-extrabold tracking-tight">{property.price}</h1>
          <span className="bg-primary/10 text-primary text-xs font-bold px-2 py-1 rounded">PREMIUM</span>
        </div>
        <h1 className="text-slate-900 dark:text-slate-100 text-xl font-bold leading-tight pt-2">{property.bhk} Luxury {property.type} • {property.sqft}</h1>
        <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400 text-sm mt-1">
          <MapPin size={14} />
          <p>{property.location}</p>
        </div>
        <div className="mt-3 inline-flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg">
          <span className="text-[10px] font-bold text-slate-500 uppercase">RERA ID</span>
          <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">PRM/KA/RERA/1251/310/AG/210125/002187</p>
        </div>
      </div>

      {/* Specs */}
      <div className="grid grid-cols-3 gap-4 px-4 py-6 border-b border-slate-100 dark:border-slate-800">
        <div className="flex flex-col items-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <Bed className="text-primary mb-1" size={20} />
          <span className="text-xs font-medium text-slate-500">4 Bedrooms</span>
        </div>
        <div className="flex flex-col items-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <Bath className="text-primary mb-1" size={20} />
          <span className="text-xs font-medium text-slate-500">4 Bathrooms</span>
        </div>
        <div className="flex flex-col items-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <Car className="text-primary mb-1" size={20} />
          <span className="text-xs font-medium text-slate-500">2 Parking</span>
        </div>
      </div>

      {/* Listed By */}
      <div className="px-4 py-6">
        <h3 className="text-slate-900 dark:text-slate-100 text-lg font-bold mb-4">Listed By</h3>
        <div className="flex items-center justify-between p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-800 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="size-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-lg">
              {property.owner.initials}
            </div>
            <div>
              <p className="font-bold text-slate-900 dark:text-slate-100">{property.owner.name}</p>
              <p className="text-xs text-slate-500">{property.owner.type}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="size-10 rounded-full bg-primary text-white flex items-center justify-center shadow-lg shadow-primary/20">
              <Phone size={18} />
            </button>
            <button className="size-10 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <MessageSquare size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Site Visit */}
      <div className="px-4 py-6 bg-slate-50 dark:bg-slate-800/30">
        <h3 className="text-slate-900 dark:text-slate-100 text-lg font-bold mb-4 flex items-center gap-2">
          <Calendar size={20} /> Book Site Visit
        </h3>
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 shadow-sm border border-slate-100 dark:border-slate-800">
          <p className="text-sm text-slate-500 mb-4 font-medium">Select a date for your visit</p>
          <div className="flex justify-between mb-6 overflow-x-auto pb-2 gap-2 no-scrollbar">
            {[
              { day: 'Mon', date: '22', active: true },
              { day: 'Tue', date: '23' },
              { day: 'Wed', date: '24' },
              { day: 'Thu', date: '25' },
              { day: 'Fri', date: '26' }
            ].map((d) => (
              <button 
                key={d.date}
                className={`flex flex-col items-center min-w-[60px] py-3 rounded-xl border transition-all ${d.active ? 'border-primary bg-primary/5 text-primary' : 'border-slate-100 dark:border-slate-800 text-slate-400'}`}
              >
                <span className="text-[10px] uppercase font-bold">{d.day}</span>
                <span className="text-lg font-bold">{d.date}</span>
              </button>
            ))}
          </div>
          <button className="w-full bg-primary text-white py-4 rounded-xl font-bold shadow-lg shadow-primary/25 transition-transform active:scale-95">
            Schedule Visit
          </button>
        </div>
      </div>

      {/* EMI Calculator */}
      <div className="px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-slate-900 dark:text-slate-100 text-lg font-bold">EMI Calculator</h3>
          <button className="text-xs text-primary font-bold">View Details</button>
        </div>
        <div className="bg-primary/5 dark:bg-primary/10 rounded-2xl p-5 border border-primary/10">
          <div className="flex justify-between items-end mb-6">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wider mb-1">Monthly Installment</p>
              <p className="text-2xl font-extrabold text-slate-900 dark:text-slate-100">₹1,84,320<span className="text-sm font-normal text-slate-500">/mo</span></p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Interest @ 8.5%</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Tenure: 20 Years</p>
            </div>
          </div>
          <div className="space-y-4">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Offers from Banks</p>
            <div className="flex items-center justify-between py-2 border-b border-primary/10">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white flex items-center justify-center p-1 border border-slate-200">
                  <img alt="HDFC" className="w-full h-auto" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/HDFC_Bank_Logo.svg/1024px-HDFC_Bank_Logo.svg.png" />
                </div>
                <span className="text-sm font-bold text-slate-700 dark:text-slate-300">HDFC Bank</span>
              </div>
              <span className="text-sm font-bold text-primary">8.45%</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white flex items-center justify-center p-1 border border-slate-200">
                  <img alt="ICICI" className="w-full h-auto" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/ICICI_Bank_Logo.svg/1200px-ICICI_Bank_Logo.svg.png" />
                </div>
                <span className="text-sm font-bold text-slate-700 dark:text-slate-300">ICICI Bank</span>
              </div>
              <span className="text-sm font-bold text-primary">8.60%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Amenities */}
      <div className="px-4 pb-12">
        <h3 className="text-slate-900 dark:text-slate-100 text-lg font-bold mb-4">Top Amenities</h3>
        <div className="flex flex-wrap gap-2">
          {property.amenities.map((amenity) => (
            <span key={amenity} className="px-4 py-2 rounded-full border border-slate-200 dark:border-slate-800 text-sm font-medium">
              {amenity}
            </span>
          ))}
          <span className="px-4 py-2 rounded-full border border-slate-200 dark:border-slate-800 text-sm font-medium">+8 More</span>
        </div>
      </div>

      {/* Location Map */}
      <div className="px-4 pb-20">
        <h3 className="text-slate-900 dark:text-slate-100 text-lg font-bold mb-4">Location</h3>
        <div className="rounded-2xl overflow-hidden h-48 bg-slate-200 relative shadow-inner">
          <img 
            className="w-full h-full object-cover" 
            src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=800&q=80" 
            alt="Map"
          />
          <div className="absolute inset-0 bg-black/10 flex items-center justify-center">
            <div className="bg-white dark:bg-slate-900 p-3 rounded-full shadow-2xl animate-bounce">
              <MapPin className="text-primary" size={32} />
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Bottom Bar */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 p-4 pb-8 flex items-center gap-3 shadow-[0_-4px_20px_-5px_rgba(0,0,0,0.1)] z-50">
        <button className="flex-1 flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white py-4 rounded-xl font-bold shadow-lg shadow-emerald-500/20 transition-all active:scale-95">
          <MessageSquare size={20} />
          WhatsApp
        </button>
        <button className="flex-1 flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white py-4 rounded-xl font-bold shadow-lg shadow-primary/20 transition-all active:scale-95">
          <Phone size={20} />
          Call Owner
        </button>
      </div>
    </motion.div>
  );
}

function MapScreen({ onBack, onSelectProperty }: { onBack: () => void, onSelectProperty: (p: Property) => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col h-screen overflow-hidden"
    >
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 pt-12 pb-4">
        <div className="flex items-center justify-between gap-3">
          <button 
            onClick={onBack}
            className="flex size-10 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex-1">
            <h1 className="text-base font-bold leading-tight">Electronic City</h1>
            <p className="text-xs text-slate-500">Bengaluru, KA</p>
          </div>
          <button className="flex size-10 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white">
            <Search size={20} />
          </button>
        </div>
        
        {/* Horizontal Filters */}
        <div className="flex gap-2 mt-4 overflow-x-auto hide-scrollbar">
          <button className="flex h-9 shrink-0 items-center justify-center gap-2 rounded-full bg-primary/10 border border-primary/20 px-4">
            <span className="text-primary text-sm font-semibold">BHK</span>
            <Plus size={14} className="text-primary rotate-45" />
          </button>
          <button className="flex h-9 shrink-0 items-center justify-center gap-2 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-4">
            <span className="text-slate-700 dark:text-slate-300 text-sm font-semibold">Budget</span>
            <Plus size={14} className="text-slate-500 rotate-45" />
          </button>
          <button className="flex h-9 shrink-0 items-center justify-center gap-2 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-4">
            <span className="text-slate-700 dark:text-slate-300 text-sm font-semibold">Possession</span>
            <Plus size={14} className="text-slate-500 rotate-45" />
          </button>
        </div>
      </div>

      {/* Map Area */}
      <div className="relative flex-1 bg-emerald-50 dark:bg-slate-900">
        {/* Placeholder Map Image */}
        <img 
          src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=1200&q=80" 
          className="w-full h-full object-cover opacity-50 dark:opacity-20"
          alt="Map"
        />

        {/* Map Overlay Pins */}
        <div className="absolute top-[30%] left-[20%] z-10">
          <div className="bg-primary text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg border-2 border-white">85L</div>
          <div className="w-0.5 h-2 bg-white mx-auto"></div>
        </div>
        <div className="absolute top-[45%] left-[60%] z-10 scale-110">
          <div className="bg-slate-900 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-xl border-2 border-white flex items-center gap-1">
            1.5Cr
            <Verified size={10} className="fill-white text-slate-900" />
          </div>
          <div className="w-0.5 h-2 bg-white mx-auto"></div>
        </div>
        <div className="absolute top-[60%] left-[35%] z-10">
          <div className="bg-primary text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg border-2 border-white">1.2Cr</div>
          <div className="w-0.5 h-2 bg-white mx-auto"></div>
        </div>
        <div className="absolute top-[35%] left-[75%] z-10">
          <div className="bg-primary text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg border-2 border-white">95L</div>
          <div className="w-0.5 h-2 bg-white mx-auto"></div>
        </div>

        {/* Map Controls */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-2">
          <button className="flex size-10 items-center justify-center rounded-lg bg-white dark:bg-slate-800 shadow-lg text-slate-700 dark:text-slate-300">
            <Plus size={20} />
          </button>
          <button className="flex size-10 items-center justify-center rounded-lg bg-white dark:bg-slate-800 shadow-lg text-slate-700 dark:text-slate-300">
            <Minus size={20} />
          </button>
          <button className="flex size-10 items-center justify-center rounded-lg bg-white dark:bg-slate-800 shadow-lg text-primary mt-4">
            <Navigation size={20} />
          </button>
        </div>
      </div>

      {/* Floating Filter Button */}
      <div className="absolute bottom-[340px] right-4 z-30">
        <button className="flex h-12 items-center justify-center gap-2 rounded-full bg-primary px-6 text-white shadow-2xl transition-transform active:scale-95">
          <Filter size={18} />
          <span className="text-sm font-bold">Filter</span>
        </button>
      </div>

      {/* Bottom Sheet Property Preview */}
      <div className="absolute bottom-0 left-0 right-0 z-40 bg-white dark:bg-slate-900 rounded-t-3xl shadow-[0_-10px_30px_rgba(0,0,0,0.1)] pt-2 pb-24 px-4">
        <div className="mx-auto h-1.5 w-12 rounded-full bg-slate-200 dark:bg-slate-800 mb-6"></div>
        <div 
          onClick={() => onSelectProperty(TRENDING_PROJECTS[1])}
          className="flex flex-col gap-4 cursor-pointer"
        >
          <div className="relative w-full h-48 rounded-2xl overflow-hidden bg-slate-100">
            <img 
              alt="Luxury apartment" 
              className="h-full w-full object-cover" 
              src="https://images.unsplash.com/photo-1567684014761-b618b6983859?auto=format&fit=crop&w=800&q=80" 
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-3 right-3 bg-white/90 dark:bg-slate-800/90 backdrop-blur rounded-full p-2 shadow-sm">
              <Heart size={20} className="text-slate-900 dark:text-white" />
            </div>
            <div className="absolute bottom-3 left-3 bg-slate-900/60 backdrop-blur-md rounded-lg px-2 py-1 flex items-center gap-1 text-white text-[10px] font-bold">
              <MapIcon size={12} /> 1/12
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">₹1.50 Cr</h3>
              <div className="flex items-center gap-1 bg-green-50 dark:bg-green-900/20 px-2 py-1 rounded text-green-700 dark:text-green-400 text-[10px] font-bold uppercase tracking-wider">
                <Verified size={12} /> Verified
              </div>
            </div>
            <div>
              <p className="text-base font-bold text-slate-800 dark:text-slate-200">Prestige Sunrise Park</p>
              <p className="text-sm text-slate-500">3 BHK Flat • Electronic City Phase 1</p>
            </div>
            <div className="flex items-center gap-3 mt-2 border-t border-slate-100 dark:border-slate-800 pt-4">
              <div className="size-10 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                <img alt="Agent" className="h-full w-full object-cover" src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80" />
              </div>
              <div className="flex-1">
                <p className="text-xs font-bold text-slate-900 dark:text-white">Ananya Rao</p>
                <p className="text-[10px] text-slate-500">Verified Agent • 4.8★</p>
              </div>
              <div className="flex gap-2">
                <button className="size-9 flex items-center justify-center rounded-full bg-primary/10 text-primary">
                  <Phone size={16} />
                </button>
                <button className="size-9 flex items-center justify-center rounded-full bg-primary text-white">
                  <Mail size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
