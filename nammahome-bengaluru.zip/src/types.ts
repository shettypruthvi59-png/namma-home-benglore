export interface Property {
  id: string;
  title: string;
  location: string;
  price: string;
  sqft: string;
  type: string;
  image: string;
  isRera?: boolean;
  isVerified?: boolean;
  bhk: string;
  amenities: string[];
  owner: {
    name: string;
    type: string;
    initials: string;
  };
}

export type Screen = 'login' | 'home' | 'details' | 'map';
